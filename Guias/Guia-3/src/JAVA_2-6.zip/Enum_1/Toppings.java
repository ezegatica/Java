package Enum_1;

public enum Toppings {
    QUESO("queso"){
        public int getPrecio(){
            return 20;
        }
    },
    TOMATE("tomate"){
        public int getPrecio(){
            return 30;
        }
    },
    CEBOLLA("cebolla"){
        public int getPrecio(){
            return 10;
        }
    };
    Toppings(String topping){
        
    } 
}


