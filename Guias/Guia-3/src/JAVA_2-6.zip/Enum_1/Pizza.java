package Enum_1;

public class Pizza {
    private int precio;
    private Coccion coccion;
    private Toppings toppings[];
    public Pizza(String coccion, String toppings[]){
        this.coccion = Coccion.valueOf(coccion);
        
    }

}
