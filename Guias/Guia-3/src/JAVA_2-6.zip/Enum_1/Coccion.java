package Enum_1;

public enum Coccion {
    PIEDRA("piedra"){
        public int getPrecio(){
            return 150;
        }
    },
    HORNO("horno"){
        public int getPrecio(){
            return 100;
        }
    };
    Coccion(String coccion){
        
    } 
}
